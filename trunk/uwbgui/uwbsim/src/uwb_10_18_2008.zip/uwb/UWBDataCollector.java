package uwb;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class UWBDataCollector {
	
	public UWBDataCollector(int port) throws IOException {
		new DataThread().start();
	}
}
