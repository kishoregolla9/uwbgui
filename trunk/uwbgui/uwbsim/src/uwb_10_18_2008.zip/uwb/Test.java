package uwb;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class Test {
	public static void main(String[] args) throws UnknownHostException{
		InetAddress ia = InetAddress.getLocalHost();
		System.out.println(ia);
		byte[] b = ia.getAddress();
		for(int i = 0; i<b.length; i++){
			System.out.println(b[i]);
		}
		
	}
}
