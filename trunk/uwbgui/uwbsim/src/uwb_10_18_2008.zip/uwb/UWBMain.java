package uwb;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.HeadlessException;
import java.awt.event.ComponentEvent;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class UWBMain {
	UWBShow gui;
	DatagramSocket serverSocket,clientSocket;
	InetAddress myAddress;
	int myPort = 9095;
	InetAddress theirAddress;
	int theirPort = 9090;
	
	public UWBMain() throws HeadlessException, IOException{
		gui = initGUI();
		myAddress = InetAddress.getLocalHost();
		theirAddress = InetAddress.getByAddress(new byte[] {18,24,1,38});
		//clientSocket = new DatagramSocket(myPort,myAddress);
		serverSocket = new DatagramSocket(myPort);
		gui.clearRadioLocs();
	}
	
	public static UWBShow initGUI() throws HeadlessException, IOException {
		UWBShow comp = new UWBShow();
        comp.setBorder(BorderFactory.createTitledBorder("Ultra-Wide Band Network Simulation"));

        // configure the applet's frame
        JFrame f = new JFrame("UWBSim");
        f.setBounds(0,0,300,300);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().setLayout( new BorderLayout() );
        f.getContentPane().add(comp,BorderLayout.CENTER);
        f.addComponentListener(new java.awt.event.ComponentAdapter() {
        	public void componentResized(ComponentEvent e) {
        		JFrame tmp = (JFrame)e.getSource();
        	    if (tmp.getWidth()<100 || tmp.getHeight()<100) {
        	    	tmp.setSize(100, 100);
        	    }
        	}
        });
        
        JPanel commPanel = new JPanel();
        commPanel.add(new JButton("this does nothing"));
        f.getContentPane().add(commPanel,BorderLayout.PAGE_END);
        
        f.pack();
        f.setLocationRelativeTo(null);
        f.setVisible(true);
        return comp;
	}
	
	public double[] extractDataFromPacket(DatagramPacket p) throws IOException{
		ByteArrayInputStream bin = new ByteArrayInputStream(p.getData() );
		DataInputStream din = new DataInputStream(bin);
		int id = din.readInt();
		int update = din.readInt();
		double x = din.readDouble();
		double y = din.readDouble();
		double[] output = {(double)id,(double)update,x,y};
		
		return output;
	}
	
	public void listenForPacketsAndUpdate() throws IOException{
		System.out.println("listen!");
		DatagramPacket packet = new DatagramPacket(new byte[256], 256);
		
		// will this wait for a packet?
		serverSocket.receive(packet);
		
		
        double data[] = extractDataFromPacket(packet);
        int id = (int)data[0];
        int update = (int)data[1];
		double x = data[2];
		double y = data[3];
		System.out.println(id);
		System.out.println(update);
		System.out.println(x);
		System.out.println(y);
		
		RadioLocation rl = new RadioLocation(id,"radio"+id,new Color(0,0,255),x,y,
    			new double[][] {});
    	gui.addRadioLoc(rl,update);
    	gui.repaint();
    	
	}
	
    public static void main(String[] args) throws InterruptedException, HeadlessException, IOException {
        UWBMain uwbm = new UWBMain();
        //System.out.println("initialize object");
        for(int i=0; i<10; i++){
        	uwbm.listenForPacketsAndUpdate();
        }
        uwbm.serverSocket.close();
        System.out.println("Socket closed.");
    }
}
