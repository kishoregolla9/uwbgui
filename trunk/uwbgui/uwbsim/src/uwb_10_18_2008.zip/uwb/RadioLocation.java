package uwb;

import java.awt.Color;

public class RadioLocation {
	int idno;
	double x, y;
	String label;
	double[][] distrib;
	Color color;
	
	public RadioLocation(int idno, String label, Color color, double x, 
			double y, double[][] distrib){
		this.idno = idno;
		this.x = x;
		this.y = y;
		this.label = label;
		this.color = color;
		this.distrib = distrib;
	}
	public RadioLocation(int idno, String label, double x, 
			double y, double[][] distrib){
		this.idno = idno;
		this.x = x;
		this.y = y;
		this.label = label;
		this.color = Color.BLACK;
		this.distrib = distrib;
	}
	
	public RadioLocation(int idno, double x, 
			double y, double[][] distrib){
		this.idno = idno;
		this.label = null;
		this.x = x;
		this.y = y;
		this.label = "";
		this.distrib = distrib;
	}
	
	public double getX(){
		return this.x;
	}
	
	public double getY(){
		return this.y;
	}
	
	public String getLabel(){
		return this.label;
	}
	
	public double[][] getDistrib(){
		return this.distrib;
	}
	
	public Color getColor(){
		return this.color;
	}
	
	public void setColor(Color color){
		this.color = color;
	}
}
