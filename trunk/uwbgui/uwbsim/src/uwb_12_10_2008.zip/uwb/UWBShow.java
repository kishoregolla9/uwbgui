package uwb;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JPanel;
 
public class UWBShow extends JPanel {
	// VARIABLES YOU CAN MODIFY
	String waypointFileLoc = "C:/java/workspace/uwbsim/src/uwb/waypoints.txt";
	String anchorFileLoc = "C:/java/workspace/uwbsim/src/uwb/anchors.txt";
	String wallFileLoc = "C:/java/workspace/uwbsim/src/uwb/walls.txt";
	Color WAYPOINT_COLOR = new Color(124,252,0); //lawn green
	Color ANCHOR_COLOR = new Color(255, 140, 0); //dark orange
	Color WALL_COLOR = new Color(0,0,0); // black
	
	// number of grid lines
    double z = 10;
    double w = 10;
	
	// other internal variables
    int canvasWidth, canvasHeight, x0, y0;
    double[][] waypoints, anchors;
    ArrayList<ArrayList<Double>> walls;
    
    boolean waypointsShow = true, anchorsShow = true, wallsShow = true;
    
    // testing variables
    //RadioLocation radio0 = new RadioLocation(0,"radio0",new Color(255,255,0),4,5,
    //		new double[][] {{0.6,1},{0.7,2},{0.9,3.5}});
    
    // three synchronized ArrayLists
    private ArrayList<RadioLocation> rls = new ArrayList<RadioLocation>(10);
    private ArrayList<Integer> rIds = new ArrayList<Integer>(10);
    private ArrayList<Integer> rRevisionNos = new ArrayList<Integer>(10);
 
    public UWBShow() throws IOException {
    	// populate lists of anchors and waypoints
    	updateAnchorList();
    	updateWaypointList();
    	updateWallList();
    }
    
    public int getIndexNo(int id){
    	// search through rIds and check each to see if it matches id
    	for(int i=0; i<rIds.size(); i++){
    		if(rIds.get(i).intValue() == id){
    			return i;
    		}
    	}
    	return -1;
    }
    
    public int getRevisionNo(int id){
    	int index = getIndexNo(id);
		return rRevisionNos.get(index).intValue();
    }
    
    public boolean addRadioLoc(RadioLocation rl, int revNum){
    	int index = getIndexNo(rl.idno);
    	
    	if(index == -1){ // so the id number of this radio location has not been added yet
    		rls.add(rls.size(),rl);
    		rIds.add(rl.idno);
    		rRevisionNos.add(revNum);
    		System.out.println("adding radio; was not here before.");
    		return true;
    	}
    	else{
    		System.out.println("Index: " + index);
        	System.out.println("ID number: " + this.rIds.get(index));
        	System.out.println("Revision number: " + this.rRevisionNos.get(index));
        	
    		// find where rl is in rls by searching by index
    		int r = getRevisionNo(rl.idno);
    		if (r < revNum){
    			System.out.println("Data provided by packet is more recent.  Update!");
    			this.rls.set(index, rl);    						// replace the RadioLocation with a new one
    			this.rRevisionNos.set(index,new Integer(revNum));	// change the revision number.
    			return true;
    		}
    		else{
    			System.out.println("Stale data in packet.  Ignore.");
    			return false;
    		}
    	}
    	
    }
    
    public void remRadioLoc(RadioLocation rl){
    	this.rls.remove(rl);
    }
    
    public void clearRadioLocs(){
    	this.rls.clear();
    }
 
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

    	// set initial size of canvas
    	Insets insets = getInsets();
        canvasWidth = getWidth() - insets.left - insets.right;
        canvasHeight = getHeight() - insets.top -insets.bottom;
        x0 = insets.left;
        y0 = insets.top;
        
        g2.setPaint(Color.WHITE);
        g2.fillRect(x0,y0,canvasWidth, canvasHeight);
        g2.setPaint(new Color(200,200,200));
        
        // draw grid lines
        for(int count = 0, x_interval = (int) Math.floor(canvasWidth/z); count <= z; count++){
        	g2.drawLine(x0+count*x_interval, y0, x0+count*x_interval, y0+canvasHeight);
        }
        for(int count = 0, y_interval = (int) Math.floor(canvasHeight/w); count <= w; count++){
        	g2.drawLine(x0, y0+count*y_interval, x0+canvasWidth, y0+count*y_interval);
        }
        g2.setPaint(Color.BLACK);
        
        // add anchors and waypoints
        if(anchorsShow){
        	addAnchors(g2, ANCHOR_COLOR);
        }
        if(waypointsShow){
        	addWaypoints(g2, WAYPOINT_COLOR);
        }
        if(wallsShow){
        	addWalls(g2,WALL_COLOR);
        }
        
        
        /*
        RadioLocation rl_two = new RadioLocation(3,"radio2",DataType.CIRCLE,
				new Color(0,0,255),5,4,2.5,0.5);
        RadioLocation rl_three = new RadioLocation(4,"radio2",DataType.CIRCLE,
				new Color(0,0,255),7,7,3,0.5);
        RadioLocation rl_four = new RadioLocation(5,"radio2",DataType.TWOPOINTS,
				new Color(0,0,255),5,4,2.5,0.5,  7,7,3,0.5);
        plotRadio(g2,rl_two);
        plotRadio(g2,rl_three);
        plotRadio(g2,rl_four);
        */
        
        for(int i = 0; i<rls.size(); i++){
        	plotRadio(g2,rls.get(i));
        }
        
    }
 
    public void plotPoint(Graphics2D g2, double x, double y){
    	// convert to coordinates in frame
    	int radius = canvasWidth/100;
    	double realX = Math.floor(x*canvasWidth/z)+x0-radius;
    	double realY = Math.floor(y*canvasHeight/w)+y0-radius;
    	g2.fill(new Ellipse2D.Double(realX, realY, 2*radius, 2*radius));
    }
    
    public Shape circle(double x, double y, double radius){
    	// convert to coordinates in frame
    	double realRadiusX = Math.floor(radius*canvasWidth/z);
    	double realRadiusY = Math.floor(radius*canvasHeight/w);
    	double realX = Math.floor(x*canvasWidth/z)+x0-realRadiusX;
    	double realY = Math.floor(y*canvasHeight/w)+y0-realRadiusY;
    	return new Ellipse2D.Double(realX, realY, 2*realRadiusX, 2*realRadiusY);
    }
    
    public void plotRadio(Graphics2D g2, RadioLocation rl){
    	DataType dt = rl.getDataType();
    	Color tempColor = g2.getColor();
    	if(dt == DataType.CIRCLE){
    		g2.setColor(rl.getColor());
    		g2.draw(circle(rl.x1,rl.y1,rl.rad1-rl.var1));
    		g2.draw(circle(rl.x1,rl.y1,rl.rad1+rl.var1));
    	}
    	else if(dt == DataType.TWOPOINTS){
    		g2.setColor(rl.getColor());
    		double[] intersections = rl.twoPointsReturn();
    		plotPoint(g2,intersections[0],intersections[1]);
    		plotPoint(g2,intersections[2],intersections[3]);
    	}
    	g2.setColor(tempColor);
    }
    
    public Color certaintyToColor(double certainty){
    	return new Color( (float) (1-certainty), 0, (float) certainty);
    }
    
    public void addAnchors(Graphics2D g2, Color c){
    	Color tempColor = g2.getColor();
    	g2.setColor(c);
    	for(int i=0; i<anchors.length; i++){
    		plotPoint(g2, anchors[i][0], anchors[i][1]);
    	}
    	g2.setColor(tempColor);
    }
    
    public void addWaypoints(Graphics2D g2, Color c){
    	Color tempColor = g2.getColor();
    	g2.setColor(c);
    	for(int i=0; i<waypoints.length; i++){
    		plotPoint(g2, waypoints[i][0], waypoints[i][1]);
    	}
    	g2.setColor(tempColor);
    }
    
    public void addWalls(Graphics2D g2, Color c){
    	Color tempColor = g2.getColor();
    	g2.setColor(c);
    	for(int i=0; i<walls.size(); i=i+2){
    		for(int j=0; j<walls.get(i).size(); j++){
    			//plotPoint(g2, walls.get(i).get(j), walls.get(i+1).get(j));
    			if(j<walls.get(i).size()-1){
    				g2.drawLine((int) Math.floor(walls.get(i).get(j).doubleValue()*canvasWidth/z)+x0,
    						(int)Math.floor(walls.get(i+1).get(j).doubleValue()*canvasHeight/w)+y0,
    						(int)Math.floor(walls.get(i).get(j+1).doubleValue()*canvasWidth/z)+x0,
    						(int)Math.floor(walls.get(i+1).get(j+1).doubleValue()*canvasHeight/w)+y0);
    			}
    		}
    	}
    	g2.setColor(tempColor);
    }
    
    public void updateAnchorList(){
    	try {
			BufferedReader in = new BufferedReader(new FileReader(anchorFileLoc));
			int len = Integer.parseInt(in.readLine().trim());
			this.anchors = new double[len][2];
			int i = 0;
			
			while(in.ready()){
				String[] tokens = in.readLine().split(" ");
				/*
				System.out.println(tokens[0]);
				System.out.println(tokens[1]);
				System.out.println(tokens[2]);
				*/
				anchors[i][0] = Double.parseDouble(tokens[0]);
				anchors[i][1] = Double.parseDouble(tokens[1]);
				//String label = tokens[2];
				i++;
			}
			in.close();
		} catch (Exception e) {
			System.out.println("Error reading anchor file.");
			e.printStackTrace();
		}
    }
    
    public void updateWaypointList(){
		try {
			BufferedReader in = new BufferedReader(new FileReader(waypointFileLoc));
			int len = Integer.parseInt(in.readLine().trim());
			this.waypoints = new double[len][2];
			int i = 0;
			
			while(in.ready()){
				String[] tokens = in.readLine().split(" ");
				/*
				System.out.println(tokens[0]);
				System.out.println(tokens[1]);
				System.out.println(tokens[2]);
				*/
				waypoints[i][0] = Double.parseDouble(tokens[0]);
				waypoints[i][1] = Double.parseDouble(tokens[1]);
				//String label = tokens[2];
				i++;
			}
			in.close();
		} catch (Exception e) {
			System.out.println("Error reading waypoint file.");
			e.printStackTrace();
		}
    }
    
    public void updateWallList(){
		try {
			BufferedReader in = new BufferedReader(new FileReader(wallFileLoc));
			this.walls = new ArrayList<ArrayList<Double>>();
			
			ArrayList<Double> currentWallX =  new ArrayList<Double>();
			ArrayList<Double> currentWallY =  new ArrayList<Double>();
			walls.add(currentWallX);
			walls.add(currentWallY);
			
			while(in.ready()){
				String line = in.readLine().trim();
				
				if (line.equals("---")){
					// new sequence of wall-points
					currentWallX = new ArrayList<Double>();
					currentWallY = new ArrayList<Double>();
					walls.add(currentWallX);
					walls.add(currentWallY);
				}
				else if (line.equals("")){
					continue;
				}	
				else{
					String[] tokens = line.split(" ");
					currentWallX.add(new Double(tokens[0]));
					currentWallY.add(new Double(tokens[1]));
				}
			}
			in.close();
		} catch (Exception e) {
			System.out.println("Error reading wall file.");
			e.printStackTrace();
		}
    }
}
