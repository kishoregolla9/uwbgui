package uwb;

enum DataType{
	ONEPOINT,
	TWOPOINTS,
	CIRCLE,
	NONE;
	
	public static DataType convert(int i){
		if(i==1){
			return CIRCLE;
		}
		else if(i==2){
			return TWOPOINTS;
		}
		else{
			return NONE;
		}
	}
}