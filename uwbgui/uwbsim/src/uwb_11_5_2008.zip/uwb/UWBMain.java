package uwb;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class UWBMain implements ActionListener {
	UWBShow gui;
	DatagramSocket serverSocket,clientSocket;
	InetAddress myAddress;
	int myPort = 9095;
	InetAddress theirAddress;
	int theirPort = 9090;
	boolean listen;
	
	public UWBMain() throws HeadlessException, IOException{
		gui = initGUI();
		myAddress = InetAddress.getLocalHost();
		theirAddress = InetAddress.getByAddress(new byte[] {18,24,1,38});
		//clientSocket = new DatagramSocket(myPort,myAddress);
		serverSocket = new DatagramSocket(myPort);
		serverSocket.setSoTimeout(1000);
		gui.clearRadioLocs();
		listen = true;
	}
	
	public UWBShow initGUI() throws HeadlessException, IOException {
		UWBShow comp = new UWBShow();
        comp.setBorder(BorderFactory.createTitledBorder("Ultra-Wide Band Network Simulation"));

        // configure the applet's frame
        JFrame f = new JFrame("UWBSim");
        f.setBounds(0,0,300,300);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().setLayout( new BorderLayout() );
        f.getContentPane().add(comp,BorderLayout.CENTER);
        f.addComponentListener(new java.awt.event.ComponentAdapter() {
        	public void componentResized(ComponentEvent e) {
        		JFrame tmp = (JFrame)e.getSource();
        	    if (tmp.getWidth()<100 || tmp.getHeight()<100) {
        	    	tmp.setSize(100, 100);
        	    }
        	}
        });
        
        JPanel commPanel = new JPanel();
        JButton b = new JButton("Stop listening for packets");
        b.setActionCommand("stop_listening");
        b.addActionListener(this);
        b.setToolTipText("Click this button when the sender has stopped sending packets.");
        commPanel.add(b);
        
        f.getContentPane().add(commPanel,BorderLayout.PAGE_END);
        
        f.pack();
        f.setLocationRelativeTo(null);
        f.setVisible(true);
        return comp;
	}
	
	public void actionPerformed(ActionEvent e){
		if (e.getActionCommand().equals("stop_listening")){
			listen = false;
		}
	}
	
	public void extractDataFromPacket(DatagramPacket p) throws IOException{
		ByteArrayInputStream bin = new ByteArrayInputStream(p.getData() );
		DataInputStream din = new DataInputStream(bin);
		int id = din.readInt();
		int update = din.readInt();
		DataType datatype = DataType.convert(din.readInt());
		RadioLocation rl;
		if(datatype==DataType.ONEPOINT){
			double x1 = din.readDouble();
			double y1 = din.readDouble();
			rl = new RadioLocation(id,"radio"+id,DataType.ONEPOINT,
    				new Color(0,0,255),x1,y1);
		}
		else if(datatype==DataType.TWOPOINTS){
			double x1 = din.readDouble();
			double y1 = din.readDouble();
			double rad1 = din.readDouble();
			double x2 = din.readDouble();
			double y2 = din.readDouble();
			double rad2 = din.readDouble();
			rl = new RadioLocation(id,"radio"+id,DataType.TWOPOINTS,
    				new Color(0,0,255),x1,y1,rad1,x2,y2,rad2);
		}
		else if(datatype==DataType.CIRCLE){
			double x1 = din.readDouble();
			double y1 = din.readDouble();
			double rad1 = din.readDouble();
			rl = new RadioLocation(id,"radio"+id,DataType.TWOPOINTS,
    				new Color(0,0,255),x1,y1,rad1);
		}
		else{
			return;
		}
    	gui.addRadioLoc(rl,update);
    	gui.repaint();
	}
	
	public void listenForPacketsAndUpdate() throws IOException{
		DatagramPacket packet = new DatagramPacket(new byte[256], 256);
		
		// will this wait for a packet?
		try{
			serverSocket.receive(packet);
		}catch(SocketTimeoutException e){
			//ignore; this is normal
			return;
		}
		
        extractDataFromPacket(packet);
	}
	
    public static void main(String[] args) throws InterruptedException, HeadlessException, IOException {
        UWBMain uwbm = new UWBMain();
        //System.out.println("initialize object");
        while(true){
        	if(uwbm.listen){
        		uwbm.listenForPacketsAndUpdate();
        	}
        	else{
        		uwbm.serverSocket.close();
        		System.out.println("Socket closed.");
        		return;
        	}
        }
    }
}
