package uwb;

import java.awt.Color;

public class RadioLocation {
	private DataType dt;
	int idno;
	double x1, y1, rad1, x2, y2, rad2;
	String label;
	Color color;
	
	public RadioLocation(int idno, String label, DataType dt, Color color ,double x1,
			double y1, double rad1, double x2, double y2, double rad2){
		this.dt = DataType.TWOPOINTS;
		this.x1 = x1;
		this.y1 = y1;
		this.rad1 = rad1;
		this.x2 = x2;
		this.y2 = y2;
		this.rad2 = rad2;
		this.label = label;
		this.color = color;
		this.idno = idno;
	}
	
	public RadioLocation(int idno, String label, DataType dt, Color color ,double x1,
			double y1, double rad1){
		this.dt = DataType.CIRCLE;
		this.x1 = x1;
		this.y1 = y1;
		this.rad1 = rad1;
		this.label = label;
		this.color = color;
		this.idno = idno;
	}
	
	public RadioLocation(int idno, String label, DataType dt, Color color ,double x1,
			double y1){
		this.dt = DataType.ONEPOINT;
		this.x1 = x1;
		this.y1 = y1;
		this.label = label;
		this.color = color;
		this.idno = idno;
	}
	
	public String getLabel(){
		return this.label;
	}
	
	public Color getColor(){
		return this.color;
	}
	
	public void setColor(Color color){
		this.color = color;
	}
	
	public DataType getDataType(){
		return this.dt;
	}
	
	public double[] twoPointsReturn(){
		if(this.dt != DataType.TWOPOINTS){
			return null;
		}
		// compute locations
		double dist = Math.sqrt(Math.pow(x1-x2,2)+Math.pow(y1-y2,2));
		double aPlusB = dist;
		double aMinusB = (Math.pow(rad1,2) - Math.pow(rad2, 2))/dist;
		double a = 0.5*(aPlusB + aMinusB);
		// double b = 0.5*(aPlusB - aMinusB);
		double perp = Math.sqrt(Math.pow(rad1,2)-Math.pow(a,2));
		double i1x = x1 + a*(x2-x1)/dist - perp*(y2-y1)/dist;
		double i1y = y1 + a*(y2-y1)/dist + perp*(x2-x1)/dist;
		double i2x = x1 + a*(x2-x1)/dist + perp*(y2-y1)/dist;
		double i2y = y1 + a*(y2-y1)/dist - perp*(x2-x1)/dist;
		double[] output = {i1x, i1y, i2x, i2y};
		return output;
	}
}
