package uwb;

enum DataType{
	ONEPOINT,
	TWOPOINTS,
	CIRCLE,
	NONE;
	
	public static DataType convert(int i){
		if(i==0){
			return ONEPOINT;
		}
		else if(i==1){
			return TWOPOINTS;
		}
		else if(i==2){
			return CIRCLE;
		}
		else{
			return NONE;
		}
	}
}