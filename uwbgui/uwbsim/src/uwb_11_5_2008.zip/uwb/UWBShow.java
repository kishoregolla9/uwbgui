package uwb;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;

import javax.swing.JPanel;
 
public class UWBShow extends JPanel {
    int canvasWidth, canvasHeight, x0, y0;
    double z = 10;
    double w = 10;
    
    // testing variables
    //RadioLocation radio0 = new RadioLocation(0,"radio0",new Color(255,255,0),4,5,
    //		new double[][] {{0.6,1},{0.7,2},{0.9,3.5}});
    
    // three synchronized ArrayLists
    private ArrayList<RadioLocation> rls = new ArrayList<RadioLocation>(10);
    private ArrayList<Integer> rIds = new ArrayList<Integer>(10);
    private ArrayList<Integer> rRevisionNos = new ArrayList<Integer>(10);
 
    public UWBShow() throws IOException {
    }
    
    public int getIndexNo(int id){
    	// search through rIds and check each to see if it matches id
    	for(int i=0; i<rIds.size(); i++){
    		if(rIds.get(i).intValue() == id){
    			return i;
    		}
    	}
    	return -1;
    }
    
    public int getRevisionNo(int id){
    	int index = getIndexNo(id);
		return rRevisionNos.get(index).intValue();
    }
    
    public boolean addRadioLoc(RadioLocation rl, int revNum){
    	int index = getIndexNo(rl.idno);
    	
    	if(index == -1){ // so the id number of this radio location has not been added yet
    		rls.add(rls.size(),rl);
    		rIds.add(rl.idno);
    		rRevisionNos.add(revNum);
    		return true;
    	}
    	else{
    		System.out.println("Index: " + index);
        	System.out.println("ID number: " + this.rIds.get(index));
        	System.out.println("Revision number: " + this.rRevisionNos.get(index));
        	
    		// find where rl is in rls by searching by index
    		int r = getRevisionNo(rl.idno);
    		if (r < revNum){
    			System.out.println("Data provided by packet is more recent.  Update!");
    			this.rls.set(index, rl);    						// replace the RadioLocation with a new one
    			this.rRevisionNos.set(index,new Integer(revNum));	// change the revision number.
    			return true;
    		}
    		else{
    			System.out.println("Stale data in packet.  Ignore.");
    			return false;
    		}
    	}
    	
    }
    
    public void remRadioLoc(RadioLocation rl){
    	this.rls.remove(rl);
    }
    
    public void clearRadioLocs(){
    	this.rls.clear();
    }
 
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        
        Insets insets = getInsets();
        canvasWidth = getWidth() - insets.left - insets.right;
        canvasHeight = getHeight() - insets.top -insets.bottom;
        x0 = insets.left;
        y0 = insets.top;

        g2.setPaint(Color.WHITE);
        g2.fillRect(x0,y0,canvasWidth, canvasHeight);
        g2.setPaint(Color.BLUE);
        
        // draw grid lines
        for(int count = 0, x_interval = (int) Math.floor(canvasWidth/z); count <= z; count++){
        	g2.drawLine(x0+count*x_interval, y0, x0+count*x_interval, y0+canvasHeight);
        }
        for(int count = 0, y_interval = (int) Math.floor(canvasHeight/w); count <= w; count++){
        	g2.drawLine(x0, y0+count*y_interval, x0+canvasWidth, y0+count*y_interval);
        }
        g2.setPaint(Color.BLACK);
        RadioLocation rl_one = new RadioLocation(2,"radio2",DataType.ONEPOINT,
				new Color(0,0,255),1,8);
        RadioLocation rl_two = new RadioLocation(3,"radio2",DataType.CIRCLE,
				new Color(0,0,255),5,4,2.5);
        RadioLocation rl_three = new RadioLocation(4,"radio2",DataType.CIRCLE,
				new Color(0,0,255),7,7,3);
        RadioLocation rl_four = new RadioLocation(5,"radio2",DataType.TWOPOINTS,
				new Color(0,0,255),5,4,2.5,7,7,3);
        plotRadio(g2,rl_one);
        plotRadio(g2,rl_two);
        plotRadio(g2,rl_three);
        plotRadio(g2,rl_four);
        /*
        for(int i = 0; i<rls.size(); i++){
        	plotRadio(g2,rls.get(i));
        }
        */
    }
 
    public void plotPoint(Graphics2D g2, double x, double y){
    	// convert to coordinates in frame
    	int radius = canvasWidth/100;
    	double realX = Math.floor(x*canvasWidth/z)+x0-radius;
    	double realY = Math.floor(y*canvasHeight/w)+y0-radius;
    	g2.fill(new Ellipse2D.Double(realX, realY, 2*radius, 2*radius));
    }
    
    public Shape circle(double x, double y, double radius){
    	// convert to coordinates in frame
    	double realRadiusX = Math.floor(radius*canvasWidth/z);
    	double realRadiusY = Math.floor(radius*canvasHeight/w);
    	double realX = Math.floor(x*canvasWidth/z)+x0-realRadiusX;
    	double realY = Math.floor(y*canvasHeight/w)+y0-realRadiusY;
    	return new Ellipse2D.Double(realX, realY, 2*realRadiusX, 2*realRadiusY);
    }
    
    public void plotRadio(Graphics2D g2, RadioLocation rl){
    	DataType dt = rl.getDataType();
    	Color tempColor = g2.getColor();
    	if(dt == DataType.ONEPOINT){
    		g2.setColor(rl.getColor());
    		plotPoint(g2,rl.x1,rl.y1);
    	}
    	else if(dt == DataType.TWOPOINTS){
    		g2.setColor(rl.getColor());
    		double[] intersections = rl.twoPointsReturn();
    		plotPoint(g2,intersections[0],intersections[1]);
    		plotPoint(g2,intersections[2],intersections[3]);
    	}
    	else if(dt == DataType.CIRCLE){
    		g2.setColor(rl.getColor());
    		g2.draw(circle(rl.x1,rl.y1,rl.rad1));    		
    	}
    	g2.setColor(tempColor);
    }
    
    public Color certaintyToColor(double certainty){
    	return new Color( (float) (1-certainty), 0, (float) certainty);
    }
}
